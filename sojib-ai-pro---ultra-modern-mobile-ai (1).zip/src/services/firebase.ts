// Firebase Realtime Database Service for SOJIB AI Pro
declare global {
  interface Window {
    firebase?: any;
  }
}

export const FIREBASE_CONFIG = {
  apiKey: "AIzaSyAUqHCN_-TI5YQwzlq5J5I6n56QkdTnDoY",
  authDomain: "sojib-top-tup-dbfc0.firebaseapp.com",
  databaseURL: "https://sojib-top-tup-dbfc0-default-rtdb.firebaseio.com",
  projectId: "sojib-top-tup-dbfc0",
  storageBucket: "sojib-top-tup-dbfc0.firebasestorage.app",
  messagingSenderId: "727540965858",
  appId: "1:727540965858:web:02061d2bbc1411f69f59bb"
};

let dbInstance: any = null;
let isInitialized = false;

export function initFirebase() {
  if (isInitialized) return dbInstance;
  try {
    if (typeof window !== 'undefined' && window.firebase) {
      if (!window.firebase.apps || window.firebase.apps.length === 0) {
        window.firebase.initializeApp(FIREBASE_CONFIG);
      }
      dbInstance = window.firebase.database();
      isInitialized = true;
    }
  } catch (err) {
    console.warn('Firebase init notice:', err);
  }
  return dbInstance;
}

export function monitorConnection(callback: (online: boolean) => void) {
  const db = initFirebase();
  if (!db) {
    callback(false);
    return () => {};
  }
  try {
    const connectedRef = db.ref('.info/connected');
    const listener = connectedRef.on('value', (snap: any) => {
      callback(snap.val() === true);
    });
    return () => connectedRef.off('value', listener);
  } catch (err) {
    callback(false);
    return () => {};
  }
}

export async function trackDeviceOnline(deviceId: string) {
  const db = initFirebase();
  if (!db || !deviceId) return;
  try {
    await db.ref(`devices/${deviceId}`).update({
      lastSeen: window.firebase.database.ServerValue.TIMESTAMP,
      userAgent: navigator.userAgent.substring(0, 120),
      language: navigator.language || 'bn',
      platform: 'web-mobile-pro'
    });
  } catch (err) {
    // Graceful silent fallback
  }
}

export async function saveChatToFirebase(deviceId: string, promptText: string) {
  const db = initFirebase();
  if (!db || !deviceId || !promptText) return;
  try {
    await db.ref(`chats/${deviceId}`).push().set({
      text: promptText,
      timestamp: window.firebase.database.ServerValue.TIMESTAMP
    });
  } catch (err) {
    // Offline local persistence will handle it
  }
}

export async function fetchChatsFromFirebase(deviceId: string): Promise<string[]> {
  const db = initFirebase();
  if (!db || !deviceId) return [];
  try {
    const snap = await db.ref(`chats/${deviceId}`).limitToLast(25).once('value');
    const data = snap.val();
    if (data) {
      return Object.values(data)
        .map((item: any) => item?.text)
        .filter(Boolean)
        .reverse() as string[];
    }
  } catch (err) {
    // Return empty on error
  }
  return [];
}

export async function checkAppActiveStatus(): Promise<{ active: boolean; message?: string }> {
  const db = initFirebase();
  if (db) {
    try {
      const snap = await db.ref('app_control').once('value');
      const data = snap.val();
      if (data && data.is_active === false) {
        return { active: false, message: data.message || "অ্যাপটি সাময়িকভাবে বন্ধ আছে।" };
      }
    } catch (err) {
      // Ignore
    }
  }
  return { active: true };
}
