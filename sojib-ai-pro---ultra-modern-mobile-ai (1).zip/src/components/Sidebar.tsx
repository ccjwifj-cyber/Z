import React from 'react';
import {
  X,
  Plus,
  Clock,
  Trash2,
  Key,
  ShieldCheck,
  Moon,
  Sun,
  MessageSquare,
  Sparkles
} from 'lucide-react';
import { triggerHaptic } from '../services/speech';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  onNewChat: () => void;
  historyList: string[];
  onSelectHistory: (text: string) => void;
  onClearHistory: () => void;
  onOpenSettings: () => void;
  theme: 'dark' | 'light';
  onToggleTheme: () => void;
  deviceId: string;
  isOwner: boolean;
}

export const Sidebar: React.FC<SidebarProps> = ({
  isOpen,
  onClose,
  onNewChat,
  historyList,
  onSelectHistory,
  onClearHistory,
  onOpenSettings,
  theme,
  onToggleTheme,
  deviceId,
  isOwner
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/70 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />

      {/* Drawer Content */}
      <div className="relative z-10 w-80 max-w-[85vw] h-full bg-slate-950 border-r border-slate-800 flex flex-col p-4 shadow-2xl">
        {/* Drawer Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-cyan-500 to-purple-600 flex items-center justify-center font-orbitron font-extrabold text-slate-950 text-sm">
              ⚡
            </div>
            <div className="font-orbitron font-bold text-sm tracking-wider text-slate-100">
              SOJIB AI PRO
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-slate-900 text-slate-400 hover:text-slate-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* User Card */}
        <div className="my-3 p-3 rounded-2xl bg-slate-900/90 border border-slate-800/80 flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center font-bold text-slate-950">
            {isOwner ? '👑' : deviceId.charAt(0).toUpperCase()}
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-xs font-bold text-slate-200 truncate flex items-center gap-1">
              <span>{isOwner ? 'সজীব স্যার (মালিক)' : 'সম্মানিত ইউজার'}</span>
              {isOwner && <ShieldCheck className="w-3.5 h-3.5 text-amber-400 shrink-0" />}
            </div>
            <div className="text-[10px] font-mono text-slate-500 truncate mt-0.5">
              ID: {deviceId.substring(0, 12).toUpperCase()}
            </div>
          </div>
        </div>

        {/* New Chat Button */}
        <button
          onClick={() => {
            triggerHaptic([20]);
            onNewChat();
            onClose();
          }}
          className="w-full mb-3 flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:brightness-110 text-slate-950 font-bold text-xs sm:text-sm active:scale-95 transition-all shadow-md shadow-cyan-500/20"
        >
          <Plus className="w-4 h-4" />
          <span>নতুন চ্যাট শুরু করুন</span>
        </button>

        {/* History Label */}
        <div className="flex items-center gap-1.5 text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-2 px-1">
          <Clock className="w-3.5 h-3.5" />
          <span>সাম্প্রতিক চ্যাট তালিকা</span>
        </div>

        {/* History List */}
        <div className="flex-1 overflow-y-auto space-y-1.5 pr-1">
          {historyList.length === 0 ? (
            <div className="text-center py-8 text-xs text-slate-500">
              কোনো সাম্প্রতিক চ্যাট নেই
            </div>
          ) : (
            historyList.map((item, idx) => (
              <button
                key={idx}
                onClick={() => {
                  triggerHaptic([20]);
                  onSelectHistory(item);
                  onClose();
                }}
                className="w-full text-left p-2.5 rounded-xl bg-slate-900/60 hover:bg-slate-800/80 border border-slate-800/60 text-xs text-slate-300 hover:text-cyan-300 truncate flex items-center gap-2 active:scale-98 transition-all"
              >
                <MessageSquare className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                <span className="truncate">{item}</span>
              </button>
            ))
          )}
        </div>

        {/* Drawer Footer Actions */}
        <div className="pt-3 border-t border-slate-800 space-y-2">
          <button
            onClick={() => {
              triggerHaptic([20]);
              onOpenSettings();
              onClose();
            }}
            className="w-full flex items-center gap-2 px-3 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs text-cyan-400 font-medium active:scale-95 transition-all"
          >
            <Key className="w-4 h-4" />
            <span>এআই চাবি ও মডেল সেটিংস</span>
          </button>

          <button
            onClick={() => {
              triggerHaptic([20]);
              onToggleTheme();
            }}
            className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs text-slate-300 font-medium active:scale-95 transition-all"
          >
            <span className="flex items-center gap-2">
              {theme === 'dark' ? <Moon className="w-4 h-4 text-purple-400" /> : <Sun className="w-4 h-4 text-amber-400" />}
              <span>থিম: {theme === 'dark' ? 'ডার্ক নিয়ন' : 'লাইট লাক্স'}</span>
            </span>
          </button>

          {historyList.length > 0 && (
            <button
              onClick={() => {
                triggerHaptic([30, 20]);
                onClearHistory();
              }}
              className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs text-rose-400 hover:bg-rose-500/10 active:scale-95 transition-all"
            >
              <Trash2 className="w-4 h-4" />
              <span>সব হিস্ট্রি মুছুন</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
