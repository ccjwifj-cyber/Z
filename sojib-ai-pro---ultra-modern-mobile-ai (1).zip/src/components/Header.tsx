import React from 'react';
import {
  Menu,
  Volume2,
  VolumeX,
  Radio,
  SlidersHorizontal,
  Monitor,
  Sparkles,
  ShieldCheck
} from 'lucide-react';

interface HeaderProps {
  onOpenSidebar: () => void;
  onOpenSettings: () => void;
  onStartLiveTalk: () => void;
  audioEnabled: boolean;
  onToggleAudio: () => void;
  screenShareActive: boolean;
  onToggleScreenShare: () => void;
  isOwner: boolean;
  isOnline: boolean;
  hasKey: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenSidebar,
  onOpenSettings,
  onStartLiveTalk,
  audioEnabled,
  onToggleAudio,
  screenShareActive,
  onToggleScreenShare,
  isOwner,
  isOnline,
  hasKey
}) => {
  return (
    <header className="relative z-30 flex items-center justify-between px-3.5 py-2.5 sm:px-5 sm:py-3 bg-slate-950/80 backdrop-blur-xl border-b border-cyan-500/10">
      {/* Left: Menu & Brand */}
      <div className="flex items-center gap-2.5 sm:gap-3.5 min-w-0">
        <button
          onClick={onOpenSidebar}
          aria-label="Open Menu"
          className="p-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-slate-300 hover:text-cyan-400 border border-slate-800 active:scale-95 transition-all"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2.5">
          <div className="relative flex items-center justify-center w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-tr from-cyan-500 via-blue-600 to-purple-600 p-0.5 shadow-lg shadow-cyan-500/20">
            <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-cyan-400 animate-pulse" />
            </div>
            <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-emerald-500 border-2 border-slate-950" />
          </div>

          <div className="flex flex-col">
            <div className="flex items-center gap-1.5">
              <h1 className="font-orbitron font-extrabold text-sm sm:text-base tracking-wider bg-gradient-to-r from-cyan-400 via-sky-200 to-purple-400 bg-clip-text text-transparent">
                SOJIB AI
              </h1>
              <span className="text-[10px] font-bold px-1.5 py-0.2 rounded-md bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                PRO
              </span>
            </div>
            <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
              {isOwner ? (
                <span className="flex items-center gap-1 text-amber-400 font-semibold">
                  <ShieldCheck className="w-3 h-3 text-amber-400" />
                  মালিক ভেরিফায়েড
                </span>
              ) : (
                <span className="flex items-center gap-1 text-emerald-400">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping inline-block" />
                  {hasKey ? 'এআই অনলাইন' : 'চাবি প্রয়োজন'}
                </span>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Right Tools */}
      <div className="flex items-center gap-1.5 sm:gap-2">
        {/* Screen Share Vision */}
        <button
          onClick={onToggleScreenShare}
          title={screenShareActive ? "স্ক্রিন শেয়ার বন্ধ করুন" : "স্ক্রিন শেয়ার ভিশন"}
          className={`p-2 rounded-xl border transition-all active:scale-95 ${
            screenShareActive
              ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-300 shadow-md shadow-emerald-500/20'
              : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:text-cyan-400'
          }`}
        >
          <Monitor className="w-4 h-4 sm:w-4.5 sm:h-4.5" />
        </button>

        {/* Live Call Button */}
        <button
          onClick={onStartLiveTalk}
          title="লাইভ কলিং চালু করুন"
          className="flex items-center gap-1 px-2.5 py-1.5 sm:px-3 sm:py-2 rounded-xl bg-gradient-to-r from-pink-600 via-rose-600 to-purple-600 text-white font-semibold text-xs shadow-lg shadow-pink-600/25 active:scale-95 transition-all hover:brightness-110"
        >
          <Radio className="w-3.5 h-3.5 animate-pulse text-white" />
          <span className="hidden xs:inline">লাইভ টক</span>
        </button>

        {/* Audio Toggle */}
        <button
          onClick={onToggleAudio}
          title={audioEnabled ? "ভয়েস রিডিং বন্ধ করুন" : "ভয়েস রিডিং চালু করুন"}
          className={`p-2 rounded-xl border transition-all active:scale-95 ${
            audioEnabled
              ? 'bg-cyan-500/15 border-cyan-500/40 text-cyan-400'
              : 'bg-slate-900/80 border-slate-800 text-slate-500 hover:text-slate-300'
          }`}
        >
          {audioEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
        </button>

        {/* Settings */}
        <button
          onClick={onOpenSettings}
          title="সেটিংস ও এআই চাবি"
          className="p-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-slate-300 hover:text-cyan-400 border border-slate-800 active:scale-95 transition-all"
        >
          <SlidersHorizontal className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
};
