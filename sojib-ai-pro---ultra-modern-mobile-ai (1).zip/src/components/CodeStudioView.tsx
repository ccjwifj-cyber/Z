import React, { useState } from 'react';
import {
  Terminal,
  Shield,
  Smartphone,
  Globe,
  FileCode,
  Copy,
  Check,
  Play,
  Download,
  Sparkles,
  Cpu
} from 'lucide-react';
import { triggerHaptic } from '../services/speech';

interface CodeStudioViewProps {
  onGenerateCode: (prompt: string) => void;
}

const TEMPLATES = [
  {
    id: 'cyber-scanner',
    title: '🛡️ নেটওয়ার্ক সিকিউরিটি স্ক্যানার',
    lang: 'python',
    desc: 'আইপি পোর্ট স্ক্যানার ও ভালনারেবিলিটি চেকার স্ক্রিপ্ট',
    code: `import socket
import sys
from datetime import datetime

# SOJIB AI PRO - Security Scanner Simulation
target_host = input("টার্গেট আইপি বা ডোমেন লিখুন: ") or "127.0.0.1"

print("-" * 50)
print(f"স্ক্যান শুরু হচ্ছে: {target_host}")
print(f"সময়: {str(datetime.now())}")
print("-" * 50)

common_ports = [21, 22, 23, 25, 53, 80, 110, 443, 3306, 8080]

try:
    for port in common_ports:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        socket.setdefaulttimeout(1)
        result = s.connect_ex((target_host, port))
        if result == 0:
            print(f"[+] Port {port}: OPEN (সক্রিয়)")
        else:
            print(f"[-] Port {port}: Closed")
        s.close()
except KeyboardInterrupt:
    print("\\nস্ক্যান বাতিল করা হয়েছে।")
    sys.exit()
`
  },
  {
    id: 'android-app',
    title: '📱 প্লে স্টোর অ্যান্ড্রয়েড ক্যালকুলেটর',
    lang: 'html',
    desc: 'প্লে স্টোরে আপলোডের উপযোগী ফুল-স্ট্যাক মোবাইল ক্যালকুলেটর PWA/Webview',
    code: `<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
  <title>Smart Pro Calculator</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; font-family: sans-serif; }
    body { background: #030712; color: #fff; display: flex; align-items: center; justify-content: center; height: 100vh; }
    .calc { width: 320px; background: #0f172a; border-radius: 24px; padding: 20px; box-shadow: 0 20px 50px rgba(0,0,0,0.6); }
    .display { background: #1e293b; padding: 18px; border-radius: 16px; font-size: 2rem; text-align: right; margin-bottom: 20px; color: #38bdf8; overflow: hidden; }
    .grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; }
    button { padding: 16px; border-radius: 14px; border: none; font-size: 1.2rem; font-weight: bold; background: #334155; color: #fff; cursor: pointer; transition: 0.1s; }
    button:active { transform: scale(0.95); }
    button.op { background: #0284c7; }
    button.eq { background: #059669; grid-column: span 2; }
    button.cl { background: #e11d48; }
  </style>
</head>
<body>
  <div class="calc">
    <div id="display" class="display">0</div>
    <div class="grid">
      <button class="cl" onclick="clearCalc()">C</button>
      <button onclick="press('/')" class="op">/</button>
      <button onclick="press('*')" class="op">*</button>
      <button onclick="press('-')" class="op">-</button>
      <button onclick="press('7')">7</button>
      <button onclick="press('8')">8</button>
      <button onclick="press('9')">9</button>
      <button onclick="press('+')" class="op">+</button>
      <button onclick="press('4')">4</button>
      <button onclick="press('5')">5</button>
      <button onclick="press('6')">6</button>
      <button onclick="calcResult()" class="eq">=</button>
      <button onclick="press('1')">1</button>
      <button onclick="press('2')">2</button>
      <button onclick="press('3')">3</button>
      <button onclick="press('0')">0</button>
    </div>
  </div>
  <script>
    let cur = '';
    function press(v) { cur += v; document.getElementById('display').innerText = cur; }
    function clearCalc() { cur = ''; document.getElementById('display').innerText = '0'; }
    function calcResult() { try { cur = eval(cur).toString(); document.getElementById('display').innerText = cur; } catch(e) { document.getElementById('display').innerText = 'ত্রুটি'; } }
  </script>
</body>
</html>`
  },
  {
    id: 'hash-cracker',
    title: '⚡ MD5 & SHA-256 হ্যাশ ক্রিপ্টোগ্রাফি',
    lang: 'python',
    desc: 'পাসওয়ার্ড সিকিউরিটি অডিটর ও ক্রিপ্টোগ্রাফিক হ্যাশার',
    code: `import hashlib

def generate_security_hashes(secret_text):
    print(f"মূল ইনপুট: {secret_text}")
    print("=" * 45)
    
    # MD5
    md5_hash = hashlib.md5(secret_text.encode()).hexdigest()
    print(f"MD5      : {md5_hash}")
    
    # SHA-1
    sha1_hash = hashlib.sha1(secret_text.encode()).hexdigest()
    print(f"SHA-1    : {sha1_hash}")
    
    # SHA-256
    sha256_hash = hashlib.sha256(secret_text.encode()).hexdigest()
    print(f"SHA-256  : {sha256_hash}")

# টেস্ট চালান
secret_input = input("টেস্ট স্ট্রিং লিখুন: ") or "AdminPassword123"
generate_security_hashes(secret_input)
`
  }
];

export const CodeStudioView: React.FC<CodeStudioViewProps> = ({ onGenerateCode }) => {
  const [activeTemplate, setActiveTemplate] = useState(TEMPLATES[0]);
  const [copied, setCopied] = useState(false);
  const [customPrompt, setCustomPrompt] = useState('');

  const handleCopy = () => {
    triggerHaptic([20]);
    navigator.clipboard.writeText(activeTemplate.code).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const handleDownload = () => {
    triggerHaptic([20]);
    const ext = activeTemplate.lang === 'python' ? 'py' : activeTemplate.lang === 'html' ? 'html' : 'js';
    const blob = new Blob([activeTemplate.code], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${activeTemplate.id}.${ext}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleGenerateCustom = () => {
    if (!customPrompt.trim()) return;
    triggerHaptic([30]);
    onGenerateCode(`দয়া করে নিম্নলিখিত চাহিদামতো সম্পূর্ণ এবং কাজ করে এমন কোড তৈরি করে দাও:\n${customPrompt}`);
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto px-3.5 py-4 sm:px-6 space-y-5 bg-slate-950 pb-20">
      {/* Studio Header */}
      <div className="flex items-center justify-between pb-3 border-b border-emerald-500/20">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-400">
            <Terminal className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-orbitron font-extrabold text-base sm:text-lg text-slate-100 tracking-wider">
              CODE & SECURITY STUDIO
            </h2>
            <p className="text-xs text-emerald-400">কোডিং, হ্যাকিং টুলস ও যেকোনো সফটওয়্যার সমাধান</p>
          </div>
        </div>
      </div>

      {/* Generator Prompt Box */}
      <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-2.5 shadow-xl">
        <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
          <Sparkles className="w-4 h-4 text-emerald-400" />
          <span>কাস্টম কোড বা টুলস তৈরি করতে চান?</span>
        </label>
        <div className="flex gap-2">
          <input
            type="text"
            value={customPrompt}
            onChange={(e) => setCustomPrompt(e.target.value)}
            placeholder="যেমন: টেলিগ্রাম বট, ওয়াইফাই পাসওয়ার্ড জেনারেটর, ফুল-স্ট্যাক পোর্টফোলিও..."
            className="flex-1 bg-slate-950 px-3.5 py-2.5 rounded-xl border border-slate-800 focus:border-emerald-500/50 text-xs sm:text-sm text-slate-100 placeholder:text-slate-500 outline-none"
          />
          <button
            onClick={handleGenerateCustom}
            disabled={!customPrompt.trim()}
            className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white font-bold text-xs sm:text-sm shrink-0 active:scale-95 transition-all shadow-md shadow-emerald-600/20"
          >
            জেনারেট
          </button>
        </div>
      </div>

      {/* Template Selector Tabs */}
      <div>
        <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
          রেডিমেড স্ক্রিপ্ট ও প্রজেক্ট নির্বাচন করুন
        </label>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
          {TEMPLATES.map((tmpl) => (
            <button
              key={tmpl.id}
              onClick={() => {
                triggerHaptic([20]);
                setActiveTemplate(tmpl);
              }}
              className={`p-3 rounded-xl border text-left transition-all active:scale-95 ${
                activeTemplate.id === tmpl.id
                  ? 'bg-emerald-500/20 border-emerald-500 text-emerald-200 shadow-md shadow-emerald-500/10 font-bold'
                  : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              <div className="text-xs font-bold truncate mb-1">{tmpl.title}</div>
              <div className="text-[11px] text-slate-400 line-clamp-1">{tmpl.desc}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Code Viewer Panel */}
      <div className="rounded-2xl overflow-hidden border border-emerald-500/30 bg-slate-950 shadow-2xl">
        <div className="flex items-center justify-between px-4 py-2.5 bg-slate-900 border-b border-slate-800">
          <div className="flex items-center gap-2 text-xs font-mono text-emerald-400 font-semibold">
            <Cpu className="w-4 h-4" />
            <span>{activeTemplate.lang.toUpperCase()}</span>
            <span className="text-slate-500">|</span>
            <span className="text-slate-300">{activeTemplate.title}</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 font-medium text-xs active:scale-95 transition-all"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'কপি হয়েছে' : 'কপি'}</span>
            </button>

            <button
              onClick={handleDownload}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 active:scale-95 transition-all"
              title="ডাউনলোড ফাইল"
            >
              <Download className="w-4 h-4" />
            </button>
          </div>
        </div>

        <pre className="p-4 overflow-x-auto text-xs sm:text-sm font-mono text-emerald-100/90 leading-relaxed max-h-[420px] overflow-y-auto">
          <code>{activeTemplate.code}</code>
        </pre>
      </div>
    </div>
  );
};
