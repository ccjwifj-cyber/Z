import React, { useState } from 'react';
import {
  Sparkles,
  Download,
  Share2,
  Copy,
  Check,
  Maximize2,
  Image as ImageIcon,
  Wand2,
  RefreshCw,
  ExternalLink
} from 'lucide-react';
import { STYLE_PRESETS, ASPECT_RATIOS, buildImageUrl, GeneratedImage } from '../services/imageGen';
import { triggerHaptic } from '../services/speech';

interface ImageStudioViewProps {
  onSendImageToChat?: (imageUrl: string, prompt: string) => void;
}

const INSPIRATION_PROMPTS = [
  {
    title: 'সাইবারপাঙ্ক রোবট',
    prompt: 'Futuristic AI android warrior in neon neon-lit cyberpunk city, ultra detailed face, glowing blue eyes',
    style: 'cyberpunk',
    category: 'Cyberpunk'
  },
  {
    title: 'রিয়ালিস্টিক রয়েল বেঙ্গল টাইগার',
    prompt: 'Majestic Royal Bengal Tiger in glowing mystical Sundarbans forest at dusk, hyperrealistic photography, 8k',
    style: 'flux-ultra',
    category: 'Wildlife'
  },
  {
    title: '৩ডি কিউট গেমিং রোবট',
    prompt: 'Cute 3D Pixar style baby robot sitting on a glowing cloud holding a shining star, soft cinematic lighting',
    style: '3d-render',
    category: '3D Pixar'
  },
  {
    title: 'ফিউচারিস্টিক ঢাকা সিটি ২০৫০',
    prompt: 'Futuristic Dhaka City in 2050 with flying cars, hyperloop tracks, glass skyscrapers with lush vertical gardens',
    style: 'flux-ultra',
    category: 'Sci-Fi'
  },
  {
    title: 'অ্যানিমে স্পেস ট্রাভেলার',
    prompt: 'Anime boy astronaut looking at a sparkling galaxy and colorful nebula, Makoto Shinkai style, high aesthetic',
    style: 'anime',
    category: 'Anime'
  },
  {
    title: 'প্রফেশনাল এআই ব্র্যান্ড লোগো',
    prompt: 'Minimalist futuristic geometric vector logo icon of an electric lightning phoenix, sleek dark gradient background',
    style: 'logo-vector',
    category: 'Branding'
  }
];

export const ImageStudioView: React.FC<ImageStudioViewProps> = ({ onSendImageToChat }) => {
  const [prompt, setPrompt] = useState('');
  const [selectedStyle, setSelectedStyle] = useState('flux-ultra');
  const [selectedRatio, setSelectedRatio] = useState('1:1');
  const [isGenerating, setIsGenerating] = useState(false);
  const [currentImage, setCurrentImage] = useState<GeneratedImage | null>({
    id: 'demo-1',
    url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80',
    prompt: 'Futuristic Glowing AI Interface with holographic neural networks and neon geometric patterns',
    style: 'dark-hologram',
    aspectRatio: '1:1',
    createdAt: Date.now()
  });
  const [gallery, setGallery] = useState<GeneratedImage[]>([]);
  const [copied, setCopied] = useState(false);
  const [fullscreenImage, setFullscreenImage] = useState<string | null>(null);

  const handleGenerate = () => {
    if (!prompt.trim() || isGenerating) return;
    triggerHaptic([30, 20]);
    setIsGenerating(true);

    const { url, finalPrompt } = buildImageUrl(prompt, selectedStyle, selectedRatio);

    // Preload image
    const img = new Image();
    img.onload = () => {
      const newImgItem: GeneratedImage = {
        id: `img-${Date.now()}`,
        url,
        prompt: finalPrompt,
        style: selectedStyle,
        aspectRatio: selectedRatio,
        createdAt: Date.now()
      };
      setCurrentImage(newImgItem);
      setGallery(prev => [newImgItem, ...prev.slice(0, 11)]);
      setIsGenerating(false);
      triggerHaptic([40, 20, 40]);
    };
    img.onerror = () => {
      setIsGenerating(false);
      alert("ছবি লোড হতে কিছুটা বিলম্ব হচ্ছে, পুনরায় চেষ্টা করুন।");
    };
    img.src = url;
  };

  const handleDownload = async (url: string, filename: string) => {
    triggerHaptic([30]);
    try {
      const response = await fetch(url);
      const blob = await response.blob();
      const blobUrl = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = `${filename.replace(/[^a-zA-Z0-9]/g, '_').substring(0, 25)}.jpg`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(blobUrl);
    } catch (err) {
      window.open(url, '_blank');
    }
  };

  const handleCopyUrl = (url: string) => {
    triggerHaptic([20]);
    navigator.clipboard.writeText(url).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto px-3.5 py-4 sm:px-6 space-y-5 bg-slate-950 pb-20">
      {/* Studio Header */}
      <div className="flex items-center justify-between pb-3 border-b border-purple-500/20">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-purple-500/15 border border-purple-500/30 text-purple-400">
            <Wand2 className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-orbitron font-extrabold text-base sm:text-lg text-slate-100 tracking-wider">
              AI IMAGE STUDIO
            </h2>
            <p className="text-xs text-purple-300">যা বলবেন ঠিক তাই তৈরি করে দেবে</p>
          </div>
        </div>
      </div>

      {/* Prompt Box */}
      <div className="space-y-3">
        <div className="relative rounded-2xl bg-slate-900/90 border border-slate-800 focus-within:border-purple-500/50 p-3 shadow-xl transition-all">
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="আপনার মনের মতো ছবির বর্ণনা দিন (যেমন: ফিউচারিস্টিক স্পেসশিপ, নিয়ন বাঘ, সুন্দর সাইবার সিটি)..."
            rows={2}
            className="w-full bg-transparent text-sm sm:text-base text-slate-100 placeholder:text-slate-500 outline-none resize-none"
          />

          <div className="flex items-center justify-between pt-2 border-t border-slate-800/80">
            <span className="text-[11px] text-slate-400">
              {prompt.length > 0 ? `${prompt.length} অক্ষর` : 'উন্নত Flux এআই ইঞ্জিন সক্রিয়'}
            </span>
            <button
              onClick={handleGenerate}
              disabled={isGenerating || !prompt.trim()}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-purple-600 via-pink-600 to-cyan-500 hover:brightness-110 text-white font-bold text-xs sm:text-sm shadow-lg shadow-purple-600/30 disabled:opacity-40 disabled:cursor-not-allowed active:scale-95 transition-all"
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>তৈরি হচ্ছে...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>ছবি তৈরি করুন</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Style Presets */}
      <div>
        <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
          আর্ট স্টাইল নির্বাচন করুন
        </label>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
          {STYLE_PRESETS.map((style) => (
            <button
              key={style.id}
              onClick={() => {
                triggerHaptic([20]);
                setSelectedStyle(style.id);
              }}
              className={`p-2.5 rounded-xl border text-left text-xs transition-all active:scale-95 ${
                selectedStyle === style.id
                  ? 'bg-purple-500/20 border-purple-500 text-purple-200 shadow-md shadow-purple-500/10 font-bold'
                  : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
              }`}
            >
              {style.name}
            </button>
          ))}
        </div>
      </div>

      {/* Aspect Ratio Selector */}
      <div>
        <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
          অ্যাসপেক্ট রেশিও (সাইজ)
        </label>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {ASPECT_RATIOS.map((ratio) => (
            <button
              key={ratio.id}
              onClick={() => {
                triggerHaptic([20]);
                setSelectedRatio(ratio.id);
              }}
              className={`p-2 rounded-xl border text-center text-xs transition-all active:scale-95 ${
                selectedRatio === ratio.id
                  ? 'bg-cyan-500/20 border-cyan-500 text-cyan-200 shadow-md shadow-cyan-500/10 font-bold'
                  : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              {ratio.label}
            </button>
          ))}
        </div>
      </div>

      {/* Generated Image Showcase */}
      {currentImage && (
        <div className="rounded-2xl overflow-hidden border border-purple-500/30 bg-slate-900/90 shadow-2xl">
          <div className="relative group">
            <img
              src={currentImage.url}
              alt={currentImage.prompt}
              className="w-full h-auto max-h-[500px] object-contain bg-black/40"
            />
            {isGenerating && (
              <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm flex flex-col items-center justify-center text-center p-4">
                <div className="w-10 h-10 border-3 border-purple-500 border-t-transparent rounded-full animate-spin mb-3" />
                <p className="font-orbitron font-bold text-sm text-purple-300 animate-pulse">
                  GENERATING MASTERPIECE...
                </p>
                <p className="text-xs text-slate-400 mt-1">হাই-রেজোলিউশন ছবি রেন্ডার হচ্ছে</p>
              </div>
            )}
          </div>

          <div className="p-3.5 sm:p-4 bg-slate-900 border-t border-slate-800 space-y-3">
            <p className="text-xs sm:text-sm text-slate-300 line-clamp-2">
              <span className="font-semibold text-purple-400">প্রম্পট: </span>
              {currentImage.prompt}
            </p>

            <div className="flex flex-wrap items-center gap-2 pt-1">
              <button
                onClick={() => handleDownload(currentImage.url, currentImage.prompt)}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-medium text-xs shadow-md active:scale-95 transition-all"
              >
                <Download className="w-4 h-4" />
                <span>ডাউনলোড</span>
              </button>

              <button
                onClick={() => handleCopyUrl(currentImage.url)}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium text-xs active:scale-95 transition-all"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                <span>{copied ? 'কপি হয়েছে' : 'লিংক কপি'}</span>
              </button>

              <button
                onClick={() => setFullscreenImage(currentImage.url)}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium text-xs active:scale-95 transition-all"
              >
                <Maximize2 className="w-4 h-4" />
                <span>ফুলস্ক্রিন</span>
              </button>

              {onSendImageToChat && (
                <button
                  onClick={() => onSendImageToChat(currentImage.url, currentImage.prompt)}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-cyan-600/20 hover:bg-cyan-600/30 text-cyan-300 font-medium text-xs border border-cyan-500/30 active:scale-95 transition-all ml-auto"
                >
                  <Share2 className="w-4 h-4" />
                  <span>চ্যাটে বিশ্লেষণ</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Inspiration Quick Ideas */}
      <div>
        <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2.5 flex items-center gap-1.5">
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span>তাত্ক্ষণিক অনুপ্রেরণা (এক ক্লিকে প্রম্পট)</span>
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {INSPIRATION_PROMPTS.map((item, idx) => (
            <div
              key={idx}
              onClick={() => {
                triggerHaptic([20]);
                setPrompt(item.prompt);
                setSelectedStyle(item.style);
              }}
              className="p-3 rounded-xl bg-slate-900/80 border border-slate-800/80 hover:border-purple-500/40 cursor-pointer active:scale-98 transition-all group"
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-bold text-slate-200 group-hover:text-purple-300">
                  {item.title}
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-purple-300 font-mono">
                  {item.category}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 line-clamp-1">{item.prompt}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Fullscreen Modal */}
      {fullscreenImage && (
        <div
          onClick={() => setFullscreenImage(null)}
          className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center p-4 backdrop-blur-md cursor-pointer"
        >
          <img
            src={fullscreenImage}
            alt="Fullscreen view"
            className="max-w-full max-h-[90vh] object-contain rounded-xl"
          />
        </div>
      )}
    </div>
  );
};
