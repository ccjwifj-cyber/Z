import React from 'react';
import { MessageSquare, Mic, Image, Terminal, Settings } from 'lucide-react';
import { TabType } from '../types';

interface BottomNavProps {
  currentTab: TabType;
  onTabChange: (tab: TabType) => void;
  onStartLiveTalk: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentTab,
  onTabChange,
  onStartLiveTalk
}) => {
  return (
    <nav className="relative z-20 flex items-center justify-around px-2 py-1.5 sm:py-2 bg-slate-950/90 backdrop-blur-2xl border-t border-slate-800/80 shadow-2xl safe-area-pb">
      {/* 1. Chat */}
      <button
        onClick={() => onTabChange('chat')}
        className={`flex flex-col items-center justify-center flex-1 py-1 rounded-xl transition-all duration-200 active:scale-95 ${
          currentTab === 'chat'
            ? 'text-cyan-400 font-semibold'
            : 'text-slate-400 hover:text-slate-200'
        }`}
      >
        <div
          className={`p-1.5 rounded-xl transition-all ${
            currentTab === 'chat' ? 'bg-cyan-500/15 shadow-sm shadow-cyan-500/20' : ''
          }`}
        >
          <MessageSquare className="w-5 h-5" />
        </div>
        <span className="text-[11px] mt-0.5">চ্যাট</span>
      </button>

      {/* 2. Image Studio */}
      <button
        onClick={() => onTabChange('image')}
        className={`flex flex-col items-center justify-center flex-1 py-1 rounded-xl transition-all duration-200 active:scale-95 ${
          currentTab === 'image'
            ? 'text-purple-400 font-semibold'
            : 'text-slate-400 hover:text-slate-200'
        }`}
      >
        <div
          className={`p-1.5 rounded-xl transition-all ${
            currentTab === 'image' ? 'bg-purple-500/15 shadow-sm shadow-purple-500/20' : ''
          }`}
        >
          <Image className="w-5 h-5" />
        </div>
        <span className="text-[11px] mt-0.5">ছবি এআই</span>
      </button>

      {/* 3. Central Glowing LIVE TALK Button */}
      <div className="relative -top-3.5 px-1 flex flex-col items-center">
        <button
          onClick={onStartLiveTalk}
          aria-label="Start Live Talk"
          className="w-13 h-13 sm:w-14 sm:h-14 rounded-full bg-gradient-to-tr from-cyan-500 via-blue-600 to-pink-500 p-0.5 shadow-xl shadow-cyan-500/30 hover:scale-105 active:scale-95 transition-transform group flex items-center justify-center"
        >
          <div className="w-full h-full rounded-full bg-slate-950/90 flex items-center justify-center">
            <Mic className="w-6 h-6 text-cyan-300 group-hover:scale-110 group-hover:text-pink-400 transition-all animate-pulse" />
          </div>
        </button>
        <span className="text-[10px] font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-pink-400 mt-1">
          লাইভ
        </span>
      </div>

      {/* 4. Code & Tools Studio */}
      <button
        onClick={() => onTabChange('tools')}
        className={`flex flex-col items-center justify-center flex-1 py-1 rounded-xl transition-all duration-200 active:scale-95 ${
          currentTab === 'tools'
            ? 'text-emerald-400 font-semibold'
            : 'text-slate-400 hover:text-slate-200'
        }`}
      >
        <div
          className={`p-1.5 rounded-xl transition-all ${
            currentTab === 'tools' ? 'bg-emerald-500/15 shadow-sm shadow-emerald-500/20' : ''
          }`}
        >
          <Terminal className="w-5 h-5" />
        </div>
        <span className="text-[11px] mt-0.5">টুলস</span>
      </button>

      {/* 5. Settings */}
      <button
        onClick={() => onTabChange('settings')}
        className={`flex flex-col items-center justify-center flex-1 py-1 rounded-xl transition-all duration-200 active:scale-95 ${
          currentTab === 'settings'
            ? 'text-amber-400 font-semibold'
            : 'text-slate-400 hover:text-slate-200'
        }`}
      >
        <div
          className={`p-1.5 rounded-xl transition-all ${
            currentTab === 'settings' ? 'bg-amber-500/15 shadow-sm shadow-amber-500/20' : ''
          }`}
        >
          <Settings className="w-5 h-5" />
        </div>
        <span className="text-[11px] mt-0.5">সেটিংস</span>
      </button>
    </nav>
  );
};
