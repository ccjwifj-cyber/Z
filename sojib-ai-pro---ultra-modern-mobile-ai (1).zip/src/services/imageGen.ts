// Multi-engine AI Image Generator & Enhancer for SOJIB AI Pro

export interface GeneratedImage {
  id: string;
  url: string;
  prompt: string;
  style: string;
  aspectRatio: string;
  createdAt: number;
}

export const STYLE_PRESETS = [
  { id: 'flux-ultra', name: 'Ultra 4K Real', promptSuffix: ', hyperrealistic, cinematic lighting, 8k resolution, shot on Hasselblad, masterpiece, highly detailed' },
  { id: 'cyberpunk', name: 'Cyberpunk Neon', promptSuffix: ', cyberpunk aesthetic, glowing neon lights, futuristic city, cinematic mood, 8k octane render' },
  { id: 'anime', name: 'Anime Master', promptSuffix: ', Makoto Shinkai style, vibrant colors, studio anime aesthetic, beautiful lighting, detailed background' },
  { id: '3d-render', name: '3D Pixar/Game', promptSuffix: ', 3d pixar animation style, c4d render, vibrant studio lighting, soft shadows, cute and detailed' },
  { id: 'dark-hologram', name: 'Holo Tech', promptSuffix: ', dark holographic interface, glowing blue and cyan particles, sci-fi futuristic design, high tech' },
  { id: 'logo-vector', name: 'Minimal Logo', promptSuffix: ', vector logo icon, modern sleek minimalism, isolated on dark gradient background, professional branding' }
];

export const ASPECT_RATIOS = [
  { id: '1:1', label: '1:1 Square (Square)', width: 1024, height: 1024 },
  { id: '9:16', label: '9:16 Mobile (Story/Wallpaper)', width: 768, height: 1344 },
  { id: '16:9', label: '16:9 Landscape (Desktop)', width: 1344, height: 768 },
  { id: '4:5', label: '4:5 Portrait (Instagram)', width: 896, height: 1120 }
];

export function buildImageUrl(prompt: string, styleId: string = 'flux-ultra', aspectRatioId: string = '1:1'): { url: string; finalPrompt: string } {
  const style = STYLE_PRESETS.find(s => s.id === styleId) || STYLE_PRESETS[0];
  const ratio = ASPECT_RATIOS.find(r => r.id === aspectRatioId) || ASPECT_RATIOS[0];
  
  const finalPrompt = `${prompt.trim()}${style.promptSuffix}`;
  const seed = Math.floor(Math.random() * 9999999);
  const encodedPrompt = encodeURIComponent(finalPrompt);
  
  // High quality Pollinations Flux generation endpoint
  const url = `https://image.pollinations.ai/prompt/${encodedPrompt}?width=${ratio.width}&height=${ratio.height}&seed=${seed}&nologo=true&enhance=true&model=flux`;
  
  return {
    url,
    finalPrompt
  };
}
