// Voice & Speech Service for SOJIB AI Pro
declare global {
  interface Window {
    responsiveVoice?: any;
    SpeechRecognition?: any;
    webkitSpeechRecognition?: any;
  }
}

export function cleanTextForAudio(raw: string): string {
  if (!raw) return '';
  return raw
    .replace(/```[\s\S]*?```/g, ' কোড ব্লক দেওয়া হয়েছে। ')
    .replace(/`([^`]+)`/g, '$1')
    .replace(/https?:\/\/\S+/gi, '')
    .replace(/[*#_~>\[\](){}\\•|]/g, '')
    .replace(/[\r\n]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

export function triggerHaptic(pattern: number[] = [30, 20, 30]) {
  if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
    try {
      navigator.vibrate(pattern);
    } catch (e) {
      // Ignore vibration error on unsupported devices
    }
  }
}

export function stopSpeaking() {
  if (typeof window !== 'undefined') {
    if (window.responsiveVoice && typeof window.responsiveVoice.cancel === 'function') {
      try {
        window.responsiveVoice.cancel();
      } catch (e) {}
    }
    if (window.speechSynthesis) {
      try {
        window.speechSynthesis.cancel();
      } catch (e) {}
    }
  }
}

export function speakBangla(
  text: string,
  options?: {
    rate?: number;
    pitch?: number;
    onStart?: () => void;
    onEnd?: () => void;
    onError?: (err?: any) => void;
  }
) {
  const clean = cleanTextForAudio(text);
  if (!clean) {
    if (options?.onEnd) options.onEnd();
    return;
  }

  stopSpeaking();

  let hasEnded = false;
  const finish = () => {
    if (hasEnded) return;
    hasEnded = true;
    if (options?.onEnd) options.onEnd();
  };

  // Try ResponsiveVoice first if available
  if (
    typeof window !== 'undefined' &&
    window.responsiveVoice &&
    typeof window.responsiveVoice.speak === 'function'
  ) {
    try {
      if (options?.onStart) options.onStart();
      window.responsiveVoice.speak(clean, "Bangla Bangladesh Female", {
        pitch: options?.pitch ?? 1.0,
        rate: options?.rate ?? 0.98,
        onstart: () => {
          if (options?.onStart) options.onStart();
        },
        onend: finish,
        onerror: () => {
          speakNativeBangla(clean, options, finish);
        }
      });

      // Safety timeout in case callback doesn't fire
      const safetyTime = Math.min(clean.length * 75 + 3000, 30000);
      setTimeout(() => {
        if (!hasEnded) finish();
      }, safetyTime);
      return;
    } catch (err) {
      speakNativeBangla(clean, options, finish);
    }
  } else {
    speakNativeBangla(clean, options, finish);
  }
}

function speakNativeBangla(
  text: string,
  options?: { rate?: number; pitch?: number; onStart?: () => void },
  onFinish?: () => void
) {
  if (typeof window === 'undefined' || !window.speechSynthesis) {
    if (onFinish) onFinish();
    return;
  }

  try {
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'bn-BD';
    utterance.rate = options?.rate ?? 1.0;
    utterance.pitch = options?.pitch ?? 1.0;

    const voices = window.speechSynthesis.getVoices();
    const bnVoice = voices.find(
      v => v.lang === 'bn-BD' || v.lang.startsWith('bn') || v.lang.includes('Bengali')
    );
    if (bnVoice) {
      utterance.voice = bnVoice;
    }

    utterance.onstart = () => {
      if (options?.onStart) options.onStart();
    };
    utterance.onend = () => {
      if (onFinish) onFinish();
    };
    utterance.onerror = () => {
      if (onFinish) onFinish();
    };

    window.speechSynthesis.speak(utterance);
  } catch (err) {
    if (onFinish) onFinish();
  }
}

export function createSpeechRecognizer(
  onResult: (text: string, isFinal: boolean) => void,
  onStart?: () => void,
  onEnd?: () => void,
  onError?: (err: any) => void
) {
  if (typeof window === 'undefined') return null;
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) return null;

  const recognition = new SR();
  recognition.lang = 'bn-BD';
  recognition.continuous = true;
  recognition.interimResults = true;

  recognition.onstart = () => {
    if (onStart) onStart();
  };

  recognition.onresult = (event: any) => {
    let interim = '';
    let final = '';
    for (let i = event.resultIndex; i < event.results.length; i++) {
      const trans = event.results[i][0].transcript;
      if (event.results[i].isFinal) {
        final += trans;
      } else {
        interim += trans;
      }
    }
    if (final.trim()) {
      onResult(final.trim(), true);
    } else if (interim.trim()) {
      onResult(interim.trim(), false);
    }
  };

  recognition.onerror = (e: any) => {
    if (onError) onError(e);
  };

  recognition.onend = () => {
    if (onEnd) onEnd();
  };

  return recognition;
}
