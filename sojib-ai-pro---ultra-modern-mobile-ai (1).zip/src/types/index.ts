export interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
  codeSnippet?: {
    lang: string;
    code: string;
  };
  imageUrl?: string;
  fileName?: string;
  isStreaming?: boolean;
}

export interface ChatSession {
  id: string;
  title: string;
  createdAt: number;
  messages: ChatMessage[];
}

export type TabType = 'chat' | 'live' | 'image' | 'tools' | 'settings';

export interface AppSettings {
  apiKey: string;
  selectedModel: string;
  audioEnabled: boolean;
  voicePitch: number;
  voiceRate: number;
  theme: 'dark' | 'light';
  ownerVerified: boolean;
  deviceId: string;
}

export interface ImagePromptPreset {
  id: string;
  title: string;
  prompt: string;
  category: 'cyberpunk' | 'realistic' | 'anime' | 'fantasy' | 'logo';
  previewUrl: string;
}
