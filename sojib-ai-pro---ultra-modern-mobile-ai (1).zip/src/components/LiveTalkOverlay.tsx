import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  MicOff,
  PhoneOff,
  Copy,
  Check,
  Radio,
  Sparkles,
  Volume2
} from 'lucide-react';
import { triggerHaptic, cleanTextForAudio } from '../services/speech';

interface LiveTalkOverlayProps {
  isOpen: boolean;
  onClose: () => void;
  onSendMessage: (text: string) => Promise<string>;
  audioEnabled: boolean;
}

export const LiveTalkOverlay: React.FC<LiveTalkOverlayProps> = ({
  isOpen,
  onClose,
  onSendMessage,
  audioEnabled
}) => {
  const [callDuration, setCallDuration] = useState(0);
  const [liveState, setLiveState] = useState<'listening' | 'thinking' | 'speaking'>('listening');
  const [liveTranscript, setLiveTranscript] = useState('শুনছি... আপনার প্রয়োজনীয় যেকোনো প্রশ্ন বা কোডের কথা বলুন।');
  const [lastAiReply, setLastAiReply] = useState('');
  const [isMicMuted, setIsMicMuted] = useState(false);
  const [copied, setCopied] = useState(false);

  const timerRef = useRef<any>(null);
  const recognitionRef = useRef<any>(null);
  const isSpeakingRef = useRef<boolean>(false);
  const isProcessingRef = useRef<boolean>(false);

  // Call duration counter
  useEffect(() => {
    if (isOpen) {
      setCallDuration(0);
      timerRef.current = setInterval(() => {
        setCallDuration(prev => prev + 1);
      }, 1000);
    } else {
      clearInterval(timerRef.current);
    }
    return () => clearInterval(timerRef.current);
  }, [isOpen]);

  // Speech Recognition Continuous Loop
  useEffect(() => {
    if (!isOpen) {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (e) {}
      }
      return;
    }

    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) {
      setLiveTranscript("আপনার ব্রাউজারে স্পিচ রিকগনিশন সাপোর্ট নেই।");
      return;
    }

    const recognition = new SR();
    recognition.lang = 'bn-BD';
    recognition.continuous = true;
    recognition.interimResults = true;

    recognition.onresult = async (event: any) => {
      if (isSpeakingRef.current || isProcessingRef.current || isMicMuted) return;

      let finalTranscript = '';
      for (let i = event.resultIndex; i < event.results.length; i++) {
        if (event.results[i].isFinal) {
          finalTranscript += event.results[i][0].transcript;
        } else {
          setLiveTranscript(`👤 ${event.results[i][0].transcript}`);
        }
      }

      if (finalTranscript.trim()) {
        const userText = finalTranscript.trim();
        setLiveTranscript(`👤 ${userText}`);
        isProcessingRef.current = true;
        setLiveState('thinking');
        triggerHaptic([30]);

        try {
          const aiResponse = await onSendMessage(userText);
          setLastAiReply(aiResponse);
          setLiveTranscript(`🤖 ${aiResponse}`);
          setLiveState('speaking');
          isSpeakingRef.current = true;

          // Speak back
          if (audioEnabled) {
            speakLiveResponse(aiResponse, () => {
              isSpeakingRef.current = false;
              isProcessingRef.current = false;
              setLiveState('listening');
            });
          } else {
            isSpeakingRef.current = false;
            isProcessingRef.current = false;
            setLiveState('listening');
          }
        } catch (err: any) {
          setLiveTranscript(`⚠️ সমস্যা: ${err.message || 'সংযোগ বিচ্ছিন্ন'}`);
          isSpeakingRef.current = false;
          isProcessingRef.current = false;
          setLiveState('listening');
        }
      }
    };

    recognition.onerror = () => {
      if (isOpen && !isMicMuted && !isSpeakingRef.current && !isProcessingRef.current) {
        setTimeout(() => {
          try {
            recognition.start();
          } catch (e) {}
        }, 500);
      }
    };

    recognition.onend = () => {
      if (isOpen && !isMicMuted && !isSpeakingRef.current && !isProcessingRef.current) {
        setTimeout(() => {
          try {
            recognition.start();
          } catch (e) {}
        }, 300);
      }
    };

    try {
      recognition.start();
    } catch (e) {}

    recognitionRef.current = recognition;

    return () => {
      try {
        recognition.stop();
      } catch (e) {}
    };
  }, [isOpen, isMicMuted, audioEnabled]);

  const speakLiveResponse = (text: string, onEnd: () => void) => {
    const clean = cleanTextForAudio(text).substring(0, 300);
    if (!clean) {
      onEnd();
      return;
    }

    if (window.responsiveVoice && typeof window.responsiveVoice.speak === 'function') {
      try {
        window.responsiveVoice.speak(clean, "Bangla Bangladesh Female", {
          pitch: 1.0,
          rate: 1.05,
          onend: onEnd,
          onerror: onEnd
        });
        return;
      } catch (e) {}
    }

    if (window.speechSynthesis) {
      const u = new SpeechSynthesisUtterance(clean);
      u.lang = 'bn-BD';
      u.rate = 1.05;
      u.onend = onEnd;
      u.onerror = onEnd;
      window.speechSynthesis.speak(u);
    } else {
      onEnd();
    }
  };

  const formatTimer = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const handleCopy = () => {
    const textToCopy = lastAiReply || liveTranscript.replace(/^[👤🤖⚠️]\s*/, '');
    if (!textToCopy) return;

    triggerHaptic([30, 30]);
    navigator.clipboard.writeText(textToCopy).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const handleToggleMute = () => {
    triggerHaptic([30]);
    setIsMicMuted(prev => !prev);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950 flex flex-col justify-between p-6 sm:p-10 select-none overflow-hidden">
      {/* Background ambient orbs */}
      <div className="absolute top-1/4 -left-20 w-80 h-80 rounded-full bg-cyan-600/15 blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 -right-20 w-80 h-80 rounded-full bg-purple-600/15 blur-3xl pointer-events-none" />

      {/* Top Header */}
      <div className="relative z-10 flex items-center justify-between w-full max-w-lg mx-auto">
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-rose-500/15 border border-rose-500/30 text-rose-300 font-bold text-xs tracking-wider">
          <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
          <Radio className="w-3.5 h-3.5" />
          <span>LIVE CALL</span>
        </div>

        <div className="font-orbitron font-bold text-cyan-400 bg-cyan-950/60 border border-cyan-500/30 px-3.5 py-1.5 rounded-full text-xs sm:text-sm tracking-widest shadow-lg shadow-cyan-500/10">
          {formatTimer(callDuration)}
        </div>
      </div>

      {/* Center Interactive Holographic Orb */}
      <div className="relative z-10 flex flex-col items-center justify-center my-auto w-full max-w-lg mx-auto text-center">
        {/* Animated Orb */}
        <div className="relative flex items-center justify-center my-6">
          {/* Wave rings */}
          <div
            className={`absolute w-52 h-52 sm:w-64 sm:h-64 rounded-full border transition-all duration-700 ${
              liveState === 'speaking'
                ? 'border-purple-500/40 animate-ping'
                : liveState === 'thinking'
                ? 'border-amber-500/40 animate-pulse'
                : 'border-cyan-500/40 animate-pulse'
            }`}
          />
          <div
            className={`absolute w-40 h-40 sm:w-48 sm:h-48 rounded-full border transition-all duration-500 ${
              liveState === 'speaking'
                ? 'border-pink-500/50 scale-105'
                : liveState === 'thinking'
                ? 'border-amber-500/50'
                : 'border-cyan-400/50'
            }`}
          />

          {/* Central Glowing Core */}
          <div
            className={`w-28 h-28 sm:w-36 sm:h-36 rounded-full flex items-center justify-center shadow-2xl transition-all duration-500 ${
              liveState === 'speaking'
                ? 'bg-gradient-to-tr from-purple-600 via-pink-600 to-rose-600 shadow-pink-500/50 scale-110'
                : liveState === 'thinking'
                ? 'bg-gradient-to-tr from-amber-500 to-orange-600 shadow-amber-500/50'
                : 'bg-gradient-to-tr from-cyan-500 to-blue-600 shadow-cyan-500/50'
            }`}
          >
            {liveState === 'speaking' ? (
              <Volume2 className="w-12 h-12 text-white animate-pulse" />
            ) : liveState === 'thinking' ? (
              <Sparkles className="w-12 h-12 text-white animate-spin" />
            ) : (
              <Mic className="w-12 h-12 text-white" />
            )}
          </div>
        </div>

        {/* State Label */}
        <h3 className="font-orbitron font-extrabold text-lg sm:text-xl text-slate-100 tracking-wider mb-1">
          SOJIB AI LIVE
        </h3>
        <p className="text-xs sm:text-sm text-cyan-400 font-medium mb-4">
          {liveState === 'speaking'
            ? '🔊 উত্তর দিচ্ছে...'
            : liveState === 'thinking'
            ? '⚡ ভাবছি...'
            : isMicMuted
            ? '🔇 মাইক্রোফোন মিউট করা'
            : '🎤 শুনছি... বাংলায় স্পষ্ট কথা বলুন'}
        </p>

        {/* Transcript Box */}
        <div className="w-full bg-slate-900/80 backdrop-blur-xl border border-cyan-500/20 rounded-2xl p-4 sm:p-5 text-left text-xs sm:text-sm text-slate-200 max-h-48 overflow-y-auto leading-relaxed shadow-xl">
          <p className="whitespace-pre-wrap">{liveTranscript}</p>
        </div>

        {/* Quick One-Click Full Answer Copy Button */}
        <button
          onClick={handleCopy}
          className="w-full mt-3 flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-purple-600 hover:brightness-110 text-slate-950 font-bold text-xs sm:text-sm shadow-lg shadow-cyan-500/20 active:scale-95 transition-all"
        >
          {copied ? (
            <>
              <Check className="w-4 h-4 text-emerald-950" />
              <span>সম্পূর্ণ উত্তর কপি হয়েছে!</span>
            </>
          ) : (
            <>
              <Copy className="w-4 h-4" />
              <span>এক ক্লিকে পুরো উত্তর কপি করুন</span>
            </>
          )}
        </button>
      </div>

      {/* Bottom Controls */}
      <div className="relative z-10 flex items-center justify-center gap-6 w-full max-w-lg mx-auto">
        {/* Mute Button */}
        <button
          onClick={handleToggleMute}
          title={isMicMuted ? "আনমিউট করুন" : "মিউট করুন"}
          className={`w-14 h-14 rounded-full flex items-center justify-center border transition-all active:scale-95 ${
            isMicMuted
              ? 'bg-rose-500/20 border-rose-500 text-rose-400'
              : 'bg-slate-900 border-slate-700 text-slate-200 hover:border-cyan-400'
          }`}
        >
          {isMicMuted ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
        </button>

        {/* End Call Button */}
        <button
          onClick={onClose}
          title="লাইভ কল শেষ করুন"
          className="w-16 h-16 rounded-full bg-gradient-to-tr from-rose-600 to-red-600 text-white flex items-center justify-center shadow-2xl shadow-rose-600/40 hover:scale-105 active:scale-95 transition-all"
        >
          <PhoneOff className="w-7 h-7" />
        </button>
      </div>
    </div>
  );
};
