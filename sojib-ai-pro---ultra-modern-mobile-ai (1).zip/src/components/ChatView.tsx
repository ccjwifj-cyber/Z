import React, { useState, useRef, useEffect } from 'react';
import {
  Send,
  Paperclip,
  Mic,
  MicOff,
  Copy,
  Check,
  Volume2,
  Sparkles,
  Code2,
  FileText,
  CornerDownLeft,
  X
} from 'lucide-react';
import { ChatMessage } from '../types';
import { triggerHaptic } from '../services/speech';

interface ChatViewProps {
  messages: ChatMessage[];
  onSendMessage: (text: string, fileData?: { dataUrl: string; mimeType: string; name: string }) => void;
  onSpeakText: (text: string) => void;
  isLoading: boolean;
  onQuickPrompt: (prompt: string) => void;
}

export const ChatView: React.FC<ChatViewProps> = ({
  messages,
  onSendMessage,
  onSpeakText,
  isLoading,
  onQuickPrompt
}) => {
  const [inputText, setInputText] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isListening, setIsListening] = useState(false);
  const [selectedFile, setSelectedFile] = useState<{ dataUrl: string; mimeType: string; name: string; isImage: boolean } | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);

  // Auto scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  // Speech Recognition Setup
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (SR) {
        const recognition = new SR();
        recognition.lang = 'bn-BD';
        recognition.continuous = false;
        recognition.interimResults = false;

        recognition.onstart = () => {
          setIsListening(true);
          triggerHaptic([40]);
        };

        recognition.onresult = (e: any) => {
          const trans = e.results[0][0].transcript;
          if (trans) {
            setInputText(prev => (prev ? `${prev} ${trans}` : trans));
          }
          setIsListening(false);
        };

        recognition.onerror = () => setIsListening(false);
        recognition.onend = () => setIsListening(false);

        recognitionRef.current = recognition;
      }
    }
  }, []);

  const handleToggleVoice = () => {
    if (!recognitionRef.current) {
      alert("আপনার ব্রাউজারে ভয়েস সাপোর্ট নেই। ক্রোম বা এজ ব্যবহার করুন।");
      return;
    }
    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      try {
        recognitionRef.current.start();
      } catch (err) {
        setIsListening(false);
      }
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 20 * 1024 * 1024) {
      alert("ফাইল সাইজ সর্বোচ্চ ২০ মেগাবাইট হতে পারবে।");
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      const isImage = file.type.startsWith('image/');
      setSelectedFile({
        dataUrl,
        mimeType: file.type || 'application/octet-stream',
        name: file.name,
        isImage
      });
      triggerHaptic([30]);
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if ((!inputText.trim() && !selectedFile) || isLoading) return;

    triggerHaptic([30]);
    onSendMessage(inputText.trim(), selectedFile || undefined);
    setInputText('');
    setSelectedFile(null);
  };

  const handleCopy = (text: string, id: string) => {
    triggerHaptic([20, 20]);
    navigator.clipboard.writeText(text).then(() => {
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    });
  };

  const parseMessageContent = (text: string) => {
    const codeBlockRegex = /```([\w+-]*)\n?([\s\S]*?)```/g;
    const parts: React.ReactNode[] = [];
    let lastIndex = 0;
    let match;

    while ((match = codeBlockRegex.exec(text)) !== null) {
      if (match.index > lastIndex) {
        parts.push(
          <span key={`text-${lastIndex}`} className="whitespace-pre-wrap leading-relaxed">
            {text.substring(lastIndex, match.index)}
          </span>
        );
      }

      const lang = match[1] || 'code';
      const code = match[2].trim();
      const codeId = `code-${match.index}`;

      parts.push(
        <div
          key={codeId}
          className="my-3 rounded-xl overflow-hidden border border-cyan-500/30 bg-slate-950/90 shadow-xl"
        >
          <div className="flex items-center justify-between px-3.5 py-2 bg-slate-900 border-b border-slate-800 text-xs">
            <div className="flex items-center gap-1.5 font-mono text-cyan-400 font-semibold">
              <Code2 className="w-3.5 h-3.5" />
              <span>{lang.toUpperCase()}</span>
            </div>
            <button
              onClick={() => handleCopy(code, codeId)}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 font-medium active:scale-95 transition-all"
            >
              {copiedId === codeId ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">কপি হয়েছে!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>কোড কপি</span>
                </>
              )}
            </button>
          </div>
          <pre className="p-3.5 overflow-x-auto text-xs sm:text-sm font-mono text-cyan-100/90 leading-relaxed max-h-96">
            <code>{code}</code>
          </pre>
        </div>
      );

      lastIndex = match.index + match[0].length;
    }

    if (lastIndex < text.length) {
      parts.push(
        <span key={`text-${lastIndex}`} className="whitespace-pre-wrap leading-relaxed">
          {text.substring(lastIndex)}
        </span>
      );
    }

    return parts;
  };

  return (
    <div className="flex flex-col h-full overflow-hidden bg-slate-950">
      {/* Quick Action Chips Bar */}
      <div className="flex items-center gap-2 px-3 py-2 overflow-x-auto no-scrollbar border-b border-slate-800/60 bg-slate-900/40">
        <button
          onClick={() => onQuickPrompt('এই অ্যাপের মালিক কে?')}
          className="flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 whitespace-nowrap active:scale-95 transition-all"
        >
          👑 মালিক কে?
        </button>
        <button
          onClick={() => onQuickPrompt('একটি প্রফেশনাল রেসপনসিভ ল্যান্ডিং পেজ এর সম্পূর্ণ HTML, CSS ও JS কোড তৈরি করো')}
          className="flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 whitespace-nowrap active:scale-95 transition-all"
        >
          💻 প্রফেশনাল ওয়েবসাইট কোড
        </button>
        <button
          onClick={() => onQuickPrompt('একটি শক্তিশালী এথিক্যাল হ্যাকিং ও সাইবার সিকিউরিটি নেটওয়ার্ক স্ক্যানার স্ক্রিপ্ট লিখে দাও')}
          className="flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-purple-500/10 hover:bg-purple-500/20 text-purple-300 border border-purple-500/30 whitespace-nowrap active:scale-95 transition-all"
        >
          🛡️ সাইবার সিকিউরিটি স্ক্রিপ্ট
        </button>
        <button
          onClick={() => onQuickPrompt('একটি প্লে স্টোরে আপলোড উপযোগী অ্যান্ড্রয়েড ক্যালকুলেটর অ্যাপ আর্কিটেকচার বানাও')}
          className="flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 whitespace-nowrap active:scale-95 transition-all"
        >
          📱 অ্যান্ড্রয়েড অ্যাপ প্রজেক্ট
        </button>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto px-3.5 py-4 space-y-4 sm:px-6">
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center min-h-[60vh] text-center p-6">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-cyan-500/20 via-blue-500/20 to-purple-500/20 border border-cyan-500/30 flex items-center justify-center mb-4 shadow-xl shadow-cyan-500/10">
              <Sparkles className="w-8 h-8 text-cyan-400 animate-pulse" />
            </div>
            <h2 className="font-orbitron font-extrabold text-xl sm:text-2xl text-slate-100 tracking-wide mb-2">
              SOJIB AI PRO
            </h2>
            <p className="text-slate-400 text-sm max-w-sm mb-6 leading-relaxed">
              যা বলবেন তাই তৈরি করে দেবে — ফুল-স্ট্যাক কোডিং, ইমেজ জেনারেটর, সাইবার সিকিউরিটি টুলস এবং লাইভ ভয়েস কলিং।
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 w-full max-w-md">
              <button
                onClick={() => onQuickPrompt('একটি চমৎকার পাইথন অটোমেশন স্ক্রিপ্ট লিখে দাও')}
                className="p-3 text-left rounded-xl bg-slate-900/80 border border-slate-800 hover:border-cyan-500/40 text-xs text-slate-300 hover:text-cyan-300 transition-all active:scale-95"
              >
                🐍 পাইথন অটোমেশন স্ক্রিপ্ট
              </button>
              <button
                onClick={() => onQuickPrompt('একটি সম্পূর্ণ রেসপনসিভ আধুনিক ই-কমার্স প্রজেক্ট বানাও')}
                className="p-3 text-left rounded-xl bg-slate-900/80 border border-slate-800 hover:border-purple-500/40 text-xs text-slate-300 hover:text-purple-300 transition-all active:scale-95"
              >
                🛍️ আধুনিক ই-কমার্স অ্যাপ
              </button>
            </div>
          </div>
        ) : (
          messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex flex-col ${
                msg.sender === 'user' ? 'items-end' : 'items-start'
              }`}
            >
              <div
                className={`max-w-[92%] sm:max-w-[85%] rounded-2xl p-3.5 sm:p-4 text-sm sm:text-base shadow-lg transition-all ${
                  msg.sender === 'user'
                    ? 'bg-gradient-to-br from-blue-600 via-indigo-600 to-purple-600 text-white rounded-tr-none'
                    : 'bg-slate-900/90 border border-cyan-500/20 text-slate-100 rounded-tl-none shadow-cyan-500/5'
                }`}
              >
                {/* Uploaded Image or File Preview */}
                {msg.imageUrl && (
                  <div className="mb-3 rounded-xl overflow-hidden border border-white/20 max-w-sm">
                    <img
                      src={msg.imageUrl}
                      alt="Uploaded preview"
                      className="w-full h-auto object-cover max-h-64"
                    />
                  </div>
                )}
                {msg.fileName && !msg.imageUrl && (
                  <div className="flex items-center gap-2 mb-2 p-2 rounded-lg bg-black/20 text-xs font-mono">
                    <FileText className="w-4 h-4 text-cyan-400" />
                    <span className="truncate">{msg.fileName}</span>
                  </div>
                )}

                {/* Message Body */}
                <div className="leading-relaxed">
                  {msg.sender === 'ai' ? parseMessageContent(msg.text) : msg.text}
                </div>

                {/* Timestamp & Actions for AI response */}
                <div className="flex items-center justify-between gap-3 mt-2.5 pt-2 border-t border-white/10 text-[11px] text-slate-400">
                  <span>{msg.timestamp}</span>

                  {msg.sender === 'ai' && (
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => onSpeakText(msg.text)}
                        title="ভয়েসে শুনুন"
                        className="flex items-center gap-1 hover:text-cyan-400 active:scale-95 transition-all"
                      >
                        <Volume2 className="w-3.5 h-3.5" />
                        <span>শুনুন</span>
                      </button>
                      <button
                        onClick={() => handleCopy(msg.text, msg.id)}
                        title="সম্পূর্ণ উত্তর কপি"
                        className="flex items-center gap-1 hover:text-cyan-400 active:scale-95 transition-all"
                      >
                        {copiedId === msg.id ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                            <span className="text-emerald-400">কপি হয়েছে</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5" />
                            <span>পুরো উত্তর কপি</span>
                          </>
                        )}
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))
        )}

        {/* Loading Indicator */}
        {isLoading && (
          <div className="flex items-center gap-3 p-3.5 rounded-2xl bg-slate-900/80 border border-cyan-500/20 max-w-xs text-xs text-slate-300 shadow-md">
            <div className="w-4 h-4 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin" />
            <span className="animate-pulse">SOJIB AI উত্তর তৈরি করছে...</span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Selected File Badge */}
      {selectedFile && (
        <div className="px-4 py-2 bg-slate-900 border-t border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs text-cyan-300 truncate">
            {selectedFile.isImage ? (
              <img
                src={selectedFile.dataUrl}
                alt="attachment preview"
                className="w-7 h-7 object-cover rounded-md border border-cyan-500/30"
              />
            ) : (
              <FileText className="w-4 h-4 text-cyan-400 shrink-0" />
            )}
            <span className="truncate">{selectedFile.name}</span>
          </div>
          <button
            onClick={() => setSelectedFile(null)}
            className="p-1 rounded-full text-slate-400 hover:text-rose-400 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Input Bar */}
      <form
        onSubmit={handleSubmit}
        className="relative z-10 p-2.5 sm:p-3 bg-slate-950/95 border-t border-slate-800/80 flex items-end gap-2"
      >
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*,video/*,audio/*,.pdf,.txt,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.csv,.json,.html,.css,.js,.md,.py,.zip"
          className="hidden"
          onChange={handleFileChange}
        />

        {/* Attachment Button */}
        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          title="ফাইল বা ফটো যুক্ত করুন"
          className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-cyan-400 border border-slate-800 active:scale-95 transition-all shrink-0"
        >
          <Paperclip className="w-5 h-5" />
        </button>

        {/* Main Input Textarea */}
        <div className="relative flex-1 bg-slate-900/90 border border-slate-800 focus-within:border-cyan-500/50 rounded-2xl transition-all">
          <textarea
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSubmit();
              }
            }}
            placeholder={isListening ? "বলুন, শুনছি..." : "যা বলবেন লিখুন (কোড, প্রজেক্ট, আইডিয়া)..."}
            rows={1}
            className="w-full bg-transparent px-3.5 py-2.5 text-sm sm:text-base text-slate-100 placeholder:text-slate-500 outline-none resize-none max-h-32 min-h-[42px]"
          />
        </div>

        {/* Mic Voice Input Button */}
        <button
          type="button"
          onClick={handleToggleVoice}
          title={isListening ? "ভয়েস রেকর্ড বন্ধ করুন" : "ভয়েসে কথা বলুন"}
          className={`p-2.5 rounded-xl border transition-all active:scale-95 shrink-0 ${
            isListening
              ? 'bg-rose-500/20 border-rose-500/60 text-rose-400 animate-pulse'
              : 'bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-cyan-400 border-slate-800'
          }`}
        >
          {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
        </button>

        {/* Send Button */}
        <button
          type="submit"
          disabled={isLoading || (!inputText.trim() && !selectedFile)}
          aria-label="বার্তা পাঠান"
          className="p-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-bold disabled:opacity-40 disabled:cursor-not-allowed hover:brightness-110 active:scale-95 transition-all shadow-md shadow-cyan-500/20 shrink-0"
        >
          <Send className="w-5 h-5" />
        </button>
      </form>
    </div>
  );
};
