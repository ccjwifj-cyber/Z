import React, { useState } from 'react';
import {
  X,
  Key,
  Cpu,
  ShieldCheck,
  Volume2,
  ExternalLink,
  ClipboardPaste,
  Check,
  RefreshCw,
  Database
} from 'lucide-react';
import { GEMINI_FALLBACK_MODELS, OWNER_SECRET } from '../services/gemini';
import { triggerHaptic } from '../services/speech';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  apiKey: string;
  onSaveApiKey: (key: string) => void;
  selectedModel: string;
  onSelectModel: (model: string) => void;
  audioEnabled: boolean;
  onToggleAudio: () => void;
  voiceRate: number;
  onChangeVoiceRate: (rate: number) => void;
  isOwner: boolean;
  onVerifyOwner: (secret: string) => boolean;
  isFirebaseConnected: boolean;
  deviceId: string;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  apiKey,
  onSaveApiKey,
  selectedModel,
  onSelectModel,
  audioEnabled,
  onToggleAudio,
  voiceRate,
  onChangeVoiceRate,
  isOwner,
  onVerifyOwner,
  isFirebaseConnected,
  deviceId
}) => {
  const [keyInput, setKeyInput] = useState(apiKey);
  const [ownerCodeInput, setOwnerCodeInput] = useState('');
  const [testStatus, setTestStatus] = useState<string | null>(null);
  const [isTesting, setIsTesting] = useState(false);
  const [copiedKey, setCopiedKey] = useState(false);

  if (!isOpen) return null;

  const handlePasteKey = async () => {
    triggerHaptic([20]);
    try {
      const text = await navigator.clipboard.readText();
      if (text) setKeyInput(text.trim());
    } catch (err) {
      alert("ক্লিপবোর্ড থেকে পেস্ট করতে ইনপুট বক্সে লং-প্রেস করুন।");
    }
  };

  const handleSave = () => {
    triggerHaptic([30, 20]);
    onSaveApiKey(keyInput.trim());
    if (ownerCodeInput.trim()) {
      onVerifyOwner(ownerCodeInput.trim());
    }
    onClose();
  };

  const handleTestKey = async () => {
    const key = keyInput.trim();
    if (!key) {
      setTestStatus("❌ আগে একটি এআই চাবি দিন");
      return;
    }
    setIsTesting(true);
    setTestStatus("সংযোগ যাচাই করা হচ্ছে...");
    try {
      const res = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${key}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents: [{ role: 'user', parts: [{ text: 'Hi' }] }]
          })
        }
      );
      const data = await res.json();
      if (res.ok && data?.candidates?.[0]?.content) {
        setTestStatus("✅ সংযোগ সফল! চাবিটি ১০০% কার্যকর।");
      } else {
        setTestStatus(`⚠️ সমস্যা: ${data?.error?.message || 'চাবি সঠিক নয়'}`);
      }
    } catch (err: any) {
      setTestStatus(`⚠️ ত্রুটি: ${err.message || 'নেটওয়ার্ক সমস্যা'}`);
    } finally {
      setIsTesting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-2xl space-y-5 my-auto max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-cyan-500/15 text-cyan-400">
              <Key className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-orbitron font-bold text-base text-slate-100">
                AI & APP SETTINGS
              </h3>
              <p className="text-xs text-slate-400">গুগল এআই চাবি ও মডেল কনফিগারেশন</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* API Key Section */}
        <div className="space-y-2">
          <label className="text-xs font-semibold text-slate-200 flex items-center justify-between">
            <span>গুগল এআই চাবি (Gemini API Key)</span>
            <a
              href="https://aistudio.google.com/app/apikey"
              target="_blank"
              rel="noreferrer"
              className="text-cyan-400 hover:underline flex items-center gap-1 text-[11px]"
            >
              <span>ফ্রি চাবি নিন</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </label>

          <div className="flex gap-2">
            <input
              type="text"
              value={keyInput}
              onChange={(e) => setKeyInput(e.target.value)}
              placeholder="AIzaSy..."
              className="flex-1 bg-slate-950 px-3 py-2.5 rounded-xl border border-slate-800 focus:border-cyan-500 text-xs sm:text-sm text-slate-100 outline-none font-mono"
            />
            <button
              onClick={handlePasteKey}
              className="px-3 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 text-xs font-medium flex items-center gap-1 shrink-0 active:scale-95 transition-all"
            >
              <ClipboardPaste className="w-3.5 h-3.5" />
              <span>পেস্ট</span>
            </button>
          </div>

          <div className="flex items-center justify-between pt-1">
            <button
              onClick={handleTestKey}
              disabled={isTesting}
              className="text-xs text-cyan-400 hover:text-cyan-300 flex items-center gap-1.5 disabled:opacity-50"
            >
              {isTesting ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : null}
              <span>সংযোগ টেস্ট করুন</span>
            </button>
            {testStatus && (
              <span className="text-[11px] font-medium text-slate-300">{testStatus}</span>
            )}
          </div>
        </div>

        {/* Gemini Model Selector */}
        <div className="space-y-2">
          <label className="text-xs font-semibold text-slate-200 flex items-center gap-1.5">
            <Cpu className="w-4 h-4 text-cyan-400" />
            <span>জেমিনি মডেল নির্বাচন (Fallback সহ)</span>
          </label>
          <div className="grid grid-cols-1 gap-1.5">
            {GEMINI_FALLBACK_MODELS.map((model) => (
              <button
                key={model}
                onClick={() => {
                  triggerHaptic([20]);
                  onSelectModel(model);
                }}
                className={`p-2.5 rounded-xl border text-left text-xs font-mono transition-all flex items-center justify-between ${
                  selectedModel === model
                    ? 'bg-cyan-500/20 border-cyan-500 text-cyan-200 font-bold'
                    : 'bg-slate-950 border-slate-800/80 text-slate-400 hover:text-slate-200'
                }`}
              >
                <span>{model}</span>
                {selectedModel === model && <Check className="w-3.5 h-3.5 text-cyan-400" />}
              </button>
            ))}
          </div>
        </div>

        {/* Master Owner Unlocker */}
        <div className="space-y-2 pt-2 border-t border-slate-800">
          <label className="text-xs font-semibold text-slate-200 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-amber-400" />
              <span>মালিক পিন কোড</span>
            </span>
            {isOwner && (
              <span className="text-[10px] px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 font-bold">
                👑 মালিক সক্রিয়
              </span>
            )}
          </label>
          <input
            type="password"
            value={ownerCodeInput}
            onChange={(e) => setOwnerCodeInput(e.target.value)}
            placeholder={isOwner ? "সজীব স্যার ভেরিফায়েড" : "মালিকের গোপন কোড দিন..."}
            className="w-full bg-slate-950 px-3 py-2 rounded-xl border border-slate-800 focus:border-amber-500 text-xs text-slate-100 outline-none font-mono"
          />
        </div>

        {/* Voice Rate Control */}
        <div className="space-y-2 pt-2 border-t border-slate-800">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-200">
            <span className="flex items-center gap-1.5">
              <Volume2 className="w-4 h-4 text-cyan-400" />
              <span>ভয়েস স্পিড: {voiceRate.toFixed(2)}x</span>
            </span>
            <button
              onClick={onToggleAudio}
              className={`text-[11px] px-2 py-0.5 rounded-md border font-medium ${
                audioEnabled
                  ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300'
                  : 'bg-slate-800 border-slate-700 text-slate-400'
              }`}
            >
              {audioEnabled ? 'ভয়েস চালু' : 'ভয়েস বন্ধ'}
            </button>
          </div>
          <input
            type="range"
            min="0.75"
            max="1.35"
            step="0.05"
            value={voiceRate}
            onChange={(e) => onChangeVoiceRate(parseFloat(e.target.value))}
            className="w-full accent-cyan-400 cursor-pointer"
          />
        </div>

        {/* Cloud & Device Info */}
        <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
          <div className="flex items-center gap-1.5">
            <Database className="w-3.5 h-3.5 text-slate-500" />
            <span>ফায়ারবেস: {isFirebaseConnected ? '✅ সংযুক্ত' : '⚠️ অফলাইন'}</span>
          </div>
          <div className="font-mono text-[10px]">
            ID: {deviceId.substring(0, 10).toUpperCase()}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-2 pt-2">
          <button
            onClick={handleSave}
            className="flex-1 py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:brightness-110 text-slate-950 font-bold text-xs sm:text-sm active:scale-95 transition-all shadow-lg shadow-cyan-500/20"
          >
            সেটিংস সেভ করুন
          </button>
          <button
            onClick={onClose}
            className="px-5 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium text-xs sm:text-sm active:scale-95 transition-all"
          >
            বন্ধ
          </button>
        </div>
      </div>
    </div>
  );
};
